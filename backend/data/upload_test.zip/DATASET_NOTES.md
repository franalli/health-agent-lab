# eval_data — Synthetic Hold-out Bundle

Synthetic data for the Health Intelligence Service. Nothing here is real patient data.

Same SHAPE as `training_data`, with new member ids (`EV01`-`EV15`) and freshly (seed-)generated
trajectories. The files are deliberately named differently from the canonical bundle to exercise the
content-based upload classifier (`POST /members/upload`):

- `cohort.json`          15 synthetic members. Each: { member_id, profile, panels, notes }.
- `panel_results.csv`    All panels across all members in long (tidy) form.
- `reference_cases.jsonl`  Labeled evaluation cases (one per line), grounded in this cohort's values.
- `DATASET_NOTES.md`     This file.

Because the names are non-canonical, this bundle loads via the upload route (which classifies by
content and rewrites to canonical names), not via `DATASET=eval_data make seed`. Reference ranges and
escalation labels are derived from the deterministic core, not hand-asserted.
